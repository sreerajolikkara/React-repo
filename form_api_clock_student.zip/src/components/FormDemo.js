import React, { Component } from 'react';

class FormDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id:'',
            name:'',
            flag:false
        };
    }

    handleChange = event => {
        this.setState({
            id: event.target.value
        });
    }
    handleChange1 = event => {
        this.setState({
            name: event.target.value
        });
    }

    handleSubmit = event => {
        for(let i in this.props.fostu){
           
        if(this.state.id==this.props.fostu[i].id)
        {
        if(this.state.name==this.props.fostu[i].name)
        console.log("successfully entered");
        this.setState({
            flag:true
        })
        break;
        }
    }  if(this.state.flag===false)
        console.log("Wrong Credentials")
        
        event.preventDefault();
        
    }
    
    render() {
        let p=(this.state.flag)?<div>success</div>:<div>failure</div>

        return (
            <div>
                <form onSubmit={this.handleSubmit}>
                    <label>
                        id:
                    <input type="text" name="id"
                            value={this.state.id}
                            onChange={this.handleChange} />
                            <br/><br/>
                            name:
                    <input type="text" name="name"
                            value={this.state.name}
                            onChange={this.handleChange1} />
                    </label>
                    <input type="submit" value="Submit" />
                </form>
                <p>
                    {p}
                                    </p>
            </div>
        );
    }
}

export default FormDemo;