import React from 'react'

const StudentDetails = props => {
    if (props.student) {
        return (
            <div className="card">
                <p>Name: {props.student.name}</p>
                <p>CGPA: {props.student.cgpa}</p>
            </div>
        )
    }
    return (
        <div>
            No student selected yet...
        </div>
    )
}

export default StudentDetails;