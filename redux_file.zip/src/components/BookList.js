import React, { Component } from 'react'
import { selectBook, deleteBook } from '../actions';
import { connect } from 'react-redux';

const style = {
    border: '1px solid blue',
    padding: '1px'
};

class BookList extends Component {
    render() {
        // console.log(this.props);
        const booklist = this.props.books.map(
            book => 
                <div className='row mb-2' 
                    style={style}
                    key={book.id}
                    onClick={() => this.props.selectBook(book)}>
                    <div className='col-auto mr-auto'>
                        {book.title}
                    </div>
                    <div className='col-auto'>
                        <button className='btn btn-danger' 
                                onClick={(e) => {e.stopPropagation(); 
                                            this.props.deleteBook(book); }}>
                            <i className='fa fa-trash'></i>
                        </button>
                    </div>
                </div>
        );
        return (
            <div>
                Book List
                <div className='container'>
                    {booklist}
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => ({books: state.bookList});


export default 
    connect(mapStateToProps, 
        { 
            selectBook, 
            deleteBook 
        })(BookList);