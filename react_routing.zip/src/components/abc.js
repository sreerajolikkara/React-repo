import React from 'react';

const Abc = () => (
  <div>
    <h1>Welcome to the Home Paasdasdasdge!</h1>
  </div>
);

export default Abc;
