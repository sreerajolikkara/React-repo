import React from 'react';

const AboutUs = () => {
    return (
        <div>
            <h2>This is the About Us Page</h2>
        </div>
    );
};

export default AboutUs;