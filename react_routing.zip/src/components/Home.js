import React from 'react';

const Home = () => (
  <div>
    <h1>Welcome to the Home Page!</h1>
  </div>
);

export default Home;
