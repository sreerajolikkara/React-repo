
import StudentList from './components/studentlist';
import './App.css';
import StudentDetails from'./components/studentdetails';
import React,{Component} from 'react';
class App extends Component{
  constructor(props)
  {
    super(props);
    this.state = {
      students: [
          { id: 101, name: 'First', cgpa: 3.8 },
          { id: 102, name: 'Second', cgpa: 2.6 },
          { id: 103, name: 'Third', cgpa: 3.0 },
          { id: 104, name: 'Fourth', cgpa: 3.3 },
          { id: 105, name: 'Fifth', cgpa: 3.7 }
      ]
  };
  this.selectedStudent=null;
}
selectstudent=(i)=>
{
  this.selectedStudent = this.state.students.filter(
    s => s.id === i.id
)[0];
this.forceUpdate();
}
  render()
  {
  return (
      <div className="container">
          Welcome
          {this.state.students[0].id}
          <StudentList studentlist={this.state.students}/>
          <StudentDetails x={this.selectedstudents}/>
      </div>
  );
}
}
export default App;
