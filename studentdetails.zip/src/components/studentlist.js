import React,{Component} from 'react';
//import StudentDetails from './studentdetails';

class StudentList extends Component
{ constructor(props)
    {
        super(props);
    };


click = () => {
    for(let i of this.props.studentlist){
        console.log(i.id);
        
    }
    
   
}

    render(){

        let temp =this.props.studentlist.map(
            i => {
            return <div>
                 <table>
                    <thead>
                        <th>
                            id
                        </th>
                        <th>
                            name
                        </th>
                        <th>
                            cgpa
                            </th>
                        </thead>
                        <tbody>
                            <tr>

                            <td>{i.id}</td>
                            <td>{i.name}</td>
                            <td>{i.cgpa}</td>
                            <button onClick={()=>this.props.selectstudent(this.props.studentlist[i])}>describe</button>
                                            </tr>
                            </tbody>
                </table>
                {/* <button onClick={() => props.onSelectStudent(i.id)}>select</button> */}
                
            </div>
            }
        )
                
        return(
            
            <div>
                <h1>{this.props.studentlist.id}</h1>
                <h1>welcome to student list</h1>
                {temp}
                <button onClick={this.click}>Add</button>
                
            </div>

        );
    }
}
export default StudentList;
