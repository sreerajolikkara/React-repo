import React,{Component} from 'react';

class StudentDetails extends Component{
    constructor(props)
    {
        super(props);
    }

    render()
    {
        if(this.props.x){
        return(
            <div>
                <table>
                    <thead>
                        <th>id</th>
                        <th>name</th>
                        <th>cgpa</th>
                        </thead>
                        <tbody>
                            <tr>
                                <th>{this.props.x.id}</th>
                                <th>{this.props.x.name}</th>
                                <th>{this.props.x.cgpa}</th>
                                </tr>
                        </tbody>
                    </table>
                </div>
        );
        }
        return(
            <div>description here</div>
        );
    }
}
export default StudentDetails;