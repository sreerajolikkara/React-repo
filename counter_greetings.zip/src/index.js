import React from 'react';
import ReactDOM from 'react-dom';

// import Greeting from './components/greeting';
// import Propsdemo from './components/propsdemo';
// import Mathtable from './components/mathtable';
// import Eventdemo from './components/eventdemo';
import Counter from './components/counter';
import Actorlist from './components/actorlist';

// First, build the component
// React components are of 3 types
// 1. Functional Components
// 2. Class Components
// 3. Controlled Components

// Here App is a functional component (the simplest type)
const App = () => {
    // const obj = {
    //     name: 'ABCD',
    //     score: 55
    // };

    return (
        <div>
            <h1>
                Welcome to React
            </h1>
            <Counter min={5} max={10} />
            <Actorlist />
        </div>
    );
}

// Reder the component
ReactDOM.render(<App />, document.querySelector('#root'));
