import React, { Component } from 'react'

export default class Actorlist extends Component {
    constructor(props) {
        super(props);
        this.state = {
            actors: [
                {name: 'ABCD', rating: 5.6},
                {name: 'EFGH', rating: 7.3},
                {name: 'IJKL', rating: 5.9},
                {name: 'MNOP', rating: 8.2},
                {name: 'QRST', rating: 5.9},
            ]
        };

        // this.deleteActor = this.deleteActor.bind(this);
    }   
    
    deleteActor = (index) => {
        // console.log(index);
        this.setState({
            actors: this.state.actors.filter(
                (actor, ndx) => ndx !== index
            )
        });
    }

    render() {
        const rows = this.state.actors.map(
            (actor, ndx) => <tr key={ndx}>
                <td>{actor.name}</td>
                <td>{actor.rating}</td>
                <td>
                    <button onClick={() => this.deleteActor(ndx)}>X</button>
                </td>
            </tr>
        );

        return (
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Rating</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {rows}
                </tbody>
            </table>
        );
    }
}

