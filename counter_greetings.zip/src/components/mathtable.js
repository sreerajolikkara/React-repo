import React from 'react';

const Mathtable = (props) => {
    const n = props.number;
    const table = [];
    for (let i = 1; i <= 10; ++i) {
        let product = n * i;
        table.push(<span key={i}>{n} x {i} = {product}<br></br></span>);
    }
    return (
        table
    );
}

export default Mathtable;