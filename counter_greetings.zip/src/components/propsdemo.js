import React from 'react';

const Propsdemo = (props) => {
    console.log('Propsdemo');
    console.log(props);

    return (
        <h5>Propsdemo</h5>
    );
}

export default Propsdemo;