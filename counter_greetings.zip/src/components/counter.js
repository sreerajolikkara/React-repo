import React, { Component } from 'react';

export default class Counter extends Component {

    constructor(props) {
        super(props);
        this.state = {
            count: this.props.min
        };

        this.increment = this.increment.bind(this);
    }

    increment() {
        // console.log('Increment Function')
        // console.log(this);
        // this.state.count++;

        this.setState({
            count: this.state.count + 1
        })
    }

    decrement() {
        // this.state.count--;

        this.setState({
            count: this.state.count - 1
        })
    }

    render() {
        return (
            <div>
            <h3>Counter Component</h3>
            <button onClick={this.decrement.bind(this)}
                    disabled={this.state.count === this.props.min}>-</button>
            &nbsp;
            {this.state.count}
            &nbsp;
            <button onClick={this.increment}
                    disabled={this.state.count === this.props.max}>+</button>
           </div> 
        );
    }
}