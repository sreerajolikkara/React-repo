// Action Creator
export function selectBook(book) {
    return {
        type: 'SELECT_BOOK',
        payload: book
    };
}

// Action creator for deleting a book

export const deleteBook = book => (
    {
        type: 'DELETE_BOOK',
        payload: book
    }
);