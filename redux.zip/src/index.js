import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'font-awesome/css/font-awesome.min.css';

import { Provider } from 'react-redux';


import App from './App';

import reducer from './reducers';

import { createStore } from 'redux';

// const store = createStore(reducer);
// console.log(store.getState());


ReactDOM.render(
    <Provider store={createStore(reducer)}>
        <App />
    </Provider>,
    document.getElementById('root')
);
