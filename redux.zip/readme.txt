npm install redux
npm install react react-redux